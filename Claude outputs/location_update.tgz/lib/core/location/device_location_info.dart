import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

import 'time_zone_locations.dart';

/// A location guessed without location permission, from the device time zone.
class EstimatedLocation {
  const EstimatedLocation({
    required this.latitude,
    required this.longitude,
    required this.countryCode,
    required this.cityName,
  });

  final double latitude;
  final double longitude;
  final String countryCode;

  /// Reference city of the time zone, e.g. "Kuala Lumpur".
  final String cityName;
}

/// Reads the device time zone (IANA id such as "Asia/Jakarta") from Android.
class DeviceLocationInfo {
  DeviceLocationInfo._();

  static const _channel = MethodChannel('com.noorquran.app/location');

  static Future<String?> timeZoneId() async {
    try {
      return await _channel.invokeMethod<String>('getTimeZoneId');
    } catch (e) {
      debugPrint('Could not read device time zone: $e');
      return null;
    }
  }

  /// The reference city of the device time zone, or null when the zone is
  /// not a geographic one (e.g. "UTC").
  static EstimatedLocation? estimateFromTimeZone(String? timeZoneId) {
    if (timeZoneId == null) return null;
    final entry = kTimeZoneLocations[timeZoneId];
    if (entry == null) return null;
    final (lat, lng, country) = entry;
    return EstimatedLocation(
      latitude: lat,
      longitude: lng,
      countryCode: country,
      cityName: timeZoneId.split('/').last.replaceAll('_', ' '),
    );
  }

  /// Country of the device time zone, used to pick the calculation method
  /// when reverse geocoding gives none.
  static String? countryFromTimeZone(String? timeZoneId) =>
      timeZoneId == null ? null : kTimeZoneLocations[timeZoneId]?.$3;
}
