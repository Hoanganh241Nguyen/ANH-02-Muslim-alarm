import 'dart:async';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';
import 'package:adhan/adhan.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../../../../core/services/in_app_prayer_scheduler.dart';
import '../../../../core/services/notification_service.dart';
import '../../domain/entities/prayer_time.dart';

/// Why the device location could not be used, so the UI can say so instead of
/// silently showing some other city.
enum LocationIssue { none, serviceDisabled, denied, deniedForever, unavailable }

class PrayerTimeProvider extends ChangeNotifier with WidgetsBindingObserver {
  PrayerTimeProvider() {
    WidgetsBinding.instance.addObserver(this);
  }

  // Last location that came from the device, so a later failure (GPS timeout,
  // permission revoked) keeps the user's own city instead of a hardcoded one.
  static const _locationBoxName = 'last_location';

  List<PrayerTime> _prayerTimes = [];
  bool _isLoading = false;
  Timer? _timer;
  Duration _timeRemaining = Duration.zero;

  /// The countdown text, updated every second on its own so that only the
  /// countdown repaints, not every listener of this provider.
  final ValueNotifier<String> countdown = ValueNotifier('00:00:00');
  PrayerTime? _nextPrayer;
  // Empty until a location is known; the UI shows "Locating..." meanwhile, or
  // why the location is unavailable.
  String _currentAddress = '';
  // Coordinates the prayer times were computed for: the device position, or
  // the last saved device position when it is unavailable. Alarms use these
  // too.
  Coordinates? _coordinates;
  bool _hasLoadedOnce = false;
  bool _hasDeviceLocation = false;
  LocationIssue _locationIssue = LocationIssue.none;

  List<PrayerTime> get prayerTimes => _prayerTimes;

  bool get isLoading => _isLoading;

  Duration get timeRemaining => _timeRemaining;

  PrayerTime? get nextPrayer => _nextPrayer;

  String get currentAddress => _currentAddress;

  bool get hasLoadedOnce => _hasLoadedOnce;

  /// Set when the last attempt to read the device location failed. Prayer
  /// times may still come from the last saved location in that case.
  LocationIssue get locationIssue => _locationIssue;

  String get timeRemainingString {
    if (_timeRemaining.isNegative) return "00:00:00";
    String twoDigits(int n) => n.toString().padLeft(2, "0");
    String hours = twoDigits(_timeRemaining.inHours);
    String minutes = twoDigits(_timeRemaining.inMinutes.remainder(60));
    String seconds = twoDigits(_timeRemaining.inSeconds.remainder(60));
    return "$hours:$minutes:$seconds";
  }

  Future<void> fetchPrayerTimes() async {
    if (_isLoading) return;
    _isLoading = true;
    notifyListeners();

    try {
      final position = await _determinePosition();
      _locationIssue = LocationIssue.none;
      _hasDeviceLocation = true;
      _setPrayerTimesForCoordinates(
        Coordinates(position.latitude, position.longitude),
      );
      _currentAddress = _formatCoordinates(
        position.latitude,
        position.longitude,
      );
      // Saved before reverse geocoding so its address write lands last.
      await _saveLastLocation(position.latitude, position.longitude);
      unawaited(_getAddressFromLatLng(position));
    } on _LocationException catch (e) {
      debugPrint('Location unavailable: ${e.issue}');
      _locationIssue = e.issue;
      await _useLastKnownLocation();
    } catch (e) {
      debugPrint('Error fetching prayer times: $e');
      _locationIssue = LocationIssue.unavailable;
      await _useLastKnownLocation();
    } finally {
      _hasLoadedOnce = true;
      _isLoading = false;
      notifyListeners();
    }
  }

  /// Falls back to the last location saved from the device. With none saved,
  /// prayer times stay empty and Home shows its "allow location / retry"
  /// state: times for a city the user is not in would be wrong, and alarms
  /// would ring at the wrong times.
  Future<void> _useLastKnownLocation() async {
    // A location from earlier in this session is still the best we have.
    if (_hasDeviceLocation && _coordinates != null) return;
    try {
      final box = await Hive.openBox(_locationBoxName);
      final lat = box.get('lat');
      final lng = box.get('lng');
      if (lat is double && lng is double) {
        _setPrayerTimesForCoordinates(Coordinates(lat, lng));
        final address = box.get('address');
        _currentAddress = address is String && address.isNotEmpty
            ? address
            : _formatCoordinates(lat, lng);
      }
    } catch (e) {
      debugPrint('Could not read last location: $e');
    }
  }

  Future<void> _saveLastLocation(
    double lat,
    double lng, {
    String? address,
  }) async {
    try {
      final box = await Hive.openBox(_locationBoxName);
      await box.putAll({
        'lat': lat,
        'lng': lng,
        if (address != null) 'address': address,
      });
      if (address == null) await box.delete('address');
    } catch (e) {
      debugPrint('Could not save last location: $e');
    }
  }

  String _formatCoordinates(double lat, double lng) =>
      '${lat.toStringAsFixed(2)}, ${lng.toStringAsFixed(2)}';

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state != AppLifecycleState.resumed) return;
    if (_hasDeviceLocation || _isLoading || !_hasLoadedOnce) return;
    unawaited(_retryIfLocationNowAvailable());
  }

  /// After the user turns location on or grants it in system Settings and
  /// comes back, load the real location without needing Retry. Only checks
  /// (never prompts) here: a permission dialog itself pauses and resumes the
  /// app, which would loop.
  Future<void> _retryIfLocationNowAvailable() async {
    final serviceEnabled = await Geolocator.isLocationServiceEnabled();
    final permission = await Geolocator.checkPermission();
    if (serviceEnabled &&
        (permission == LocationPermission.always ||
            permission == LocationPermission.whileInUse)) {
      await fetchPrayerTimes();
    }
  }

  void _setPrayerTimesForCoordinates(Coordinates coordinates) {
    _coordinates = coordinates;
    final params = CalculationMethod.muslim_world_league.getParameters();
    params.madhab = Madhab.shafi;

    final date = DateComponents.from(DateTime.now());
    final prayerTimesData = PrayerTimes(coordinates, date, params);

    _prayerTimes = _convertToList(prayerTimesData);

    _updateCurrentAndNextPrayer();
    InAppPrayerScheduler.instance.schedule(_prayerTimes);
    _scheduleMultiDayNotifications(); // Lập lịch cho nhiều ngày
    _startTimer();
  }

  List<PrayerTime> _convertToList(PrayerTimes data) {
    return [
      PrayerTime(
        type: PrayerType.fajr,
        time: data.fajr,
        soundStatus: SoundStatus.ring,
      ),
      PrayerTime(
        type: PrayerType.dhuhr,
        time: data.dhuhr,
        soundStatus: SoundStatus.ring,
      ),
      PrayerTime(
        type: PrayerType.asr,
        time: data.asr,
        soundStatus: SoundStatus.ring,
      ),
      PrayerTime(
        type: PrayerType.maghrib,
        time: data.maghrib,
        soundStatus: SoundStatus.ring,
      ),
      PrayerTime(
        type: PrayerType.isha,
        time: data.isha,
        soundStatus: SoundStatus.ring,
      ),
    ];
  }

  void _updateCurrentAndNextPrayer() {
    final now = DateTime.now();
    try {
      _nextPrayer = _prayerTimes.firstWhere((p) => p.time.isAfter(now));
    } catch (_) {
      _nextPrayer = _calculateTomorrowFajr();
    }
    if (_nextPrayer != null) {
      _timeRemaining = _nextPrayer!.time.difference(now);
      countdown.value = timeRemainingString;
    }

    for (int i = 0; i < _prayerTimes.length; i++) {
      final p = _prayerTimes[i];
      final nextP = (i < _prayerTimes.length - 1) ? _prayerTimes[i + 1] : null;
      bool isCurrent = false;
      if (nextP != null) {
        isCurrent = now.isAfter(p.time) && now.isBefore(nextP.time);
      } else {
        isCurrent = now.isAfter(p.time);
      }
      _prayerTimes[i] = PrayerTime(
        type: p.type,
        time: p.time,
        isCurrent: isCurrent,
        soundStatus: p.soundStatus,
      );
    }
  }

  PrayerTime _calculateTomorrowFajr() {
    final coordinates = _coordinates;
    if (coordinates == null) {
      return PrayerTime(
        type: PrayerType.fajr,
        time: DateTime.now().add(const Duration(hours: 5)), // Fallback
        soundStatus: SoundStatus.ring,
      );
    }
    final tomorrow = DateTime.now().add(const Duration(days: 1));
    final params = CalculationMethod.muslim_world_league.getParameters();
    final prayerTimesData = PrayerTimes(
      coordinates,
      DateComponents.from(tomorrow),
      params,
    );
    return PrayerTime(
      type: PrayerType.fajr,
      time: prayerTimesData.fajr,
      soundStatus: SoundStatus.ring,
    );
  }

  Future<void> _scheduleMultiDayNotifications() async {
    final coordinates = _coordinates;
    if (coordinates == null) return;
    final notificationService = NotificationService();
    // Do not cancel all every time to avoid clearing pending alarms unnecessarily
    // await notificationService.cancelAllNotifications();

    final params = CalculationMethod.muslim_world_league.getParameters();

    // Lập lịch cho 7 ngày tới để đảm bảo ngay cả khi kill app lâu ngày vẫn có báo thức
    for (int i = 0; i < 7; i++) {
      final date = DateTime.now().add(Duration(days: i));
      final prayerTimesData = PrayerTimes(
        coordinates,
        DateComponents.from(date),
        params,
      );
      final dailyPrayers = _convertToList(prayerTimesData);

      for (var prayer in dailyPrayers) {
        if (prayer.time.isAfter(DateTime.now())) {
          await notificationService.scheduleNotification(
            id: prayer.type.index + (i * 10),
            // Unique ID cho mỗi ngày
            title: prayer.name,
            body: prayer.name,
            scheduledDate: prayer.time,
            payload: prayer.name,
          );
        }
      }
    }
  }

  void _startTimer() {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      final now = DateTime.now();
      if (_nextPrayer != null) {
        _timeRemaining = _nextPrayer!.time.difference(now);
        if (_timeRemaining.isNegative) {
          _updateCurrentAndNextPrayer();
          notifyListeners();
        }
        countdown.value = timeRemainingString;
      }
    });
  }

  void toggleSoundStatus(PrayerType type) {
    final index = _prayerTimes.indexWhere((p) => p.type == type);
    if (index != -1) {
      final currentStatus = _prayerTimes[index].soundStatus;
      SoundStatus nextStatus;
      switch (currentStatus) {
        case SoundStatus.ring:
          nextStatus = SoundStatus.vibrate;
          break;
        case SoundStatus.vibrate:
          nextStatus = SoundStatus.silent;
          break;
        case SoundStatus.silent:
          nextStatus = SoundStatus.ring;
          break;
      }

      _prayerTimes[index] = PrayerTime(
        type: _prayerTimes[index].type,
        time: _prayerTimes[index].time,
        isCurrent: _prayerTimes[index].isCurrent,
        soundStatus: nextStatus,
      );
      notifyListeners();

      // Update notifications after status change
      _scheduleMultiDayNotifications();
    }
  }

  Future<void> _getAddressFromLatLng(Position position) async {
    try {
      List<Placemark> placemarks = await placemarkFromCoordinates(
        position.latitude,
        position.longitude,
      );
      if (placemarks.isNotEmpty) {
        final place = placemarks[0];
        final city = [
          place.locality,
          place.subAdministrativeArea,
          place.administrativeArea,
        ].firstWhere((p) => p != null && p.trim().isNotEmpty, orElse: () => '');
        final address = [city, place.country]
            .where((p) => p != null && p.trim().isNotEmpty)
            .join(', ');
        if (address.isEmpty) return;
        _currentAddress = address;
        notifyListeners();
        unawaited(
          _saveLastLocation(
            position.latitude,
            position.longitude,
            address: address,
          ),
        );
      }
    } catch (_) {}
  }

  Future<Position> _determinePosition() async {
    final serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      throw const _LocationException(LocationIssue.serviceDisabled);
    }
    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.denied) {
      throw const _LocationException(LocationIssue.denied);
    }
    if (permission == LocationPermission.deniedForever) {
      throw const _LocationException(LocationIssue.deniedForever);
    }
    try {
      // City-level accuracy is enough for prayer times, and unlike high
      // accuracy it does not make Google prompt for "Location Accuracy" on
      // every request.
      return await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.low,
        timeLimit: const Duration(seconds: 15),
      );
    } catch (e) {
      // No fresh fix in time (indoors, emulator, flaky network location):
      // the position the OS last saw is still the user's city.
      final last = await Geolocator.getLastKnownPosition();
      if (last != null) return last;
      debugPrint('No current or last known position: $e');
      throw const _LocationException(LocationIssue.unavailable);
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _timer?.cancel();
    countdown.dispose();
    InAppPrayerScheduler.instance.cancelAll();
    super.dispose();
  }
}

class _LocationException implements Exception {
  const _LocationException(this.issue);

  final LocationIssue issue;
}
